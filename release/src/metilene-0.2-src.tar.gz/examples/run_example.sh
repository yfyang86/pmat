#!/bin/sh
./pmat -t 40 -a A -b B -X 8 -Y 8 -m 5 -d 0.05 salt.test.dat > test.dat.DMR
